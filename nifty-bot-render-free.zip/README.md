# NIFTY BOT - TREND FIB + AUTO TOKEN - RENDER FREE

## Logic
- TREND High-Low (Last 30 candles)
- Fib 0.5 Entry, 0.32 SL + Trailing, 2.14 Target
- W Pattern Double Bottom
- Auto Token Regenerate - TOTP 30sec + JWT 6hr + Expired auto login

## Deploy to Render (100% FREE)

### Quick Steps:

1. GitHub Repo Banav:
   - nifty-bot-render-free navacha repo banav
   - Ya folder madhle sagle files push kar

2. Render.com:
   - New -> Web Service -> Tumcha repo select
   - Environment: Docker
   - Plan: FREE
   - Add ENV vars:
     ANGEL_API_KEY, ANGEL_CLIENT_ID, ANGEL_PASSWORD, ANGEL_TOTP_SECRET
     TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID

3. Deploy -> URL yeil: https://your-app.onrender.com

4. 24/7 Sathi UptimeRobot:
   - uptimerobot.com -> Add Monitor -> URL: https://your-app.onrender.com/
   - Interval 5 min -> Bot kadhich sleep honar nahi!

### Dashboard:
- / -> Status
- /dashboard -> P&L Chart
- /status -> JSON API
- /logs -> Logs
- Telegram -> Mobile signals

### Cost: $0/month FREE!

See RENDER_GUIDE.html for full guide
