"""
RENDER DEPLOYMENT - NIFTY BOT
Web Service + Background Bot Thread
- Flask web server for Render health check + P&L dashboard
- Bot runs in background thread 24/7
- Auto Token Regenerate ON
"""

import os, threading, time
from datetime import datetime
from flask import Flask, send_from_directory, jsonify

app = Flask(__name__)

# Global bot status
bot_status = {
    "running": False,
    "last_login": None,
    "last_signal": None,
    "pnl_today": 0,
    "trades_today": 0,
    "token_auto": "ON",
    "logic": "TREND HIGH-LOW FIB 0.5/0.32/2.14 + W PATTERN",
    "started_at": datetime.now().isoformat()
}

def run_bot():
    """Run bot in background thread"""
    global bot_status
    try:
        print("[RENDER] Starting bot thread...")
        # Import bot's main
        import bot_live_1lot
        bot_status["running"] = True
        bot_status["last_login"] = datetime.now().isoformat()
        # Run bot's main loop (this blocks)
        bot_live_1lot.main()
    except Exception as e:
        print(f"[RENDER] Bot thread error: {e}")
        import traceback
        traceback.print_exc()
        bot_status["running"] = False
        # Auto restart after 10 sec
        time.sleep(10)
        run_bot()

@app.route('/')
def home():
    return f"""
    <html>
    <head><title>Nifty Bot - Render</title>
    <style>
    body{{background:#0f172a;color:white;font-family:Arial;padding:20px}}
    .card{{background:#1e293b;padding:20px;border-radius:12px;margin:15px 0}}
    h1{{color:#22c55e}} .green{{color:#22c55e}} .yellow{{color:#facc15}}
    a{{color:#3b82f6}}
    </style>
    </head>
    <body>
    <h1>🚀 NIFTY BOT - TREND FIB + AUTO TOKEN - RENDER LIVE</h1>
    <div class="card">
    <h2>✅ Bot Status: {'🟢 RUNNING' if bot_status['running'] else '🔴 STOPPED'}</h2>
    <p>Started: {bot_status['started_at']}<br>
    Logic: {bot_status['logic']}<br>
    Token Auto: {bot_status['token_auto']}<br>
    Last Login: {bot_status['last_login']}</p>
    </div>
    <div class="card">
    <h2>📊 Dashboard</h2>
    <p><a href="/dashboard">📈 P&L Dashboard - Click Here</a></p>
    <p><a href="/status">🔍 JSON Status API</a></p>
    <p><a href="/logs">📝 Logs</a></p>
    </div>
    <div class="card">
    <h2>💡 Render Info</h2>
    <p>Render free tier: Bot sleeps after 15 min if no web request<br>
    Solution: Use UptimeRobot to ping this URL every 5 min -> Bot 24/7!<br>
    <br>
    <b>UptimeRobot Setup:</b><br>
    1. uptimerobot.com var account banav<br>
    2. Add Monitor -> HTTP(s) -> URL: https://YOUR_APP.onrender.com/<br>
    3. Interval: 5 min<br>
    4. Bot kadhich sleep honar nahi!
    </p>
    </div>
    <div class="card">
    <h2>🔑 Auto Token Regenerate</h2>
    <p>✅ TOTP 30sec auto<br>
    ✅ JWT 6hr auto regenerate<br>
    ✅ Token Expired -> Auto login<br>
    ✅ Market Closed -> Auto waiting<br>
    Perfect for Render 24/7!</p>
    </div>
    </body>
    </html>
    """

@app.route('/dashboard')
def dashboard():
    return send_from_directory('.', 'pnl_chart.html')

@app.route('/status')
def status():
    # Try to read P&L
    try:
        with open('pnl_today.txt','r') as f:
            pnl = f.read().strip()
            bot_status['pnl_today'] = pnl
    except:
        pass
    try:
        with open('paper_signals.csv','r') as f:
            lines = f.readlines()
            bot_status['trades_today'] = max(0, len(lines)-1)
            if lines and len(lines)>1:
                bot_status['last_signal'] = lines[-1][:100]
    except:
        pass
    return jsonify(bot_status)

@app.route('/logs')
def logs():
    log_text = ""
    try:
        with open('paper_signals.csv','r') as f:
            log_text += "=== PAPER SIGNALS ===\n" + f.read()[-2000:] + "\n\n"
    except:
        log_text += "No paper_signals.csv yet\n\n"
    try:
        with open('trades_log.csv','r') as f:
            log_text += "=== TRADES LOG ===\n" + f.read()[-2000:] + "\n\n"
    except:
        log_text += "No trades_log.csv yet\n\n"
    try:
        with open('pnl_today.txt','r') as f:
            log_text += f"=== P&L TODAY: {f.read()} ===\n"
    except:
        pass
    return f"<pre style='background:#000;color:#0f0;padding:20px;overflow:auto'>{log_text}</pre><a href='/'>Back</a>"

if __name__ == '__main__':
    # Start bot in background thread
    bot_thread = threading.Thread(target=run_bot, daemon=True)
    bot_thread.start()
    print("[RENDER] Bot thread started in background")
    print("[RENDER] Starting Flask web server...")
    # Render uses PORT env var
    port = int(os.environ.get('PORT', 10000))
    app.run(host='0.0.0.0', port=port, debug=False)
