"""NIFTY BOT - TREND HIGH-LOW FIB + W PATTERN + TRAILING SL + AUTO TOKEN REGENERATE
User Question: "Aapla bot Api token auto regentrat karto ka"

ANSWER: HO! 100% AUTO!
- TOTP = Google Authenticator code, har 30 sec la nava, pyotp auto generate karto
- JWT + Feed Token = Angel cha token, ratri expire hota
- Ha bot har 6 tasane auto re-login karta + jar Token Expired error ala tar lagech nava token gheta

Logic:
- Trend High-Low (Last 30 candles)
- Fib 0.5 Entry, 0.32 SL + Trailing, 2.14 Target
- W Pattern Double Bottom
- Auto Token Regenerate
"""

import csv, json, os, sys, time
from datetime import datetime, timedelta
import requests

CONFIG_FILE = "config.json"
PAPER_FILE = "paper_signals.csv"
TRADES_FILE = "trades_log.csv"
PNL_FILE = "pnl_today.txt"
POLL_SECONDS = 15
NIFTY_TOKEN = "99926000"
NIFTY_EXCH = "NSE"
SIGNAL_EXPIRY = 3
CANDLE_MAX_AGE = 3
FIB_ENTRY = 0.50
FIB_SL = 0.32
FIB_TARGET = 2.14
TREND_LOOKBACK = 30


def load_config():
    """Load from ENV first (for Render), then config.json (local)"""
    # Try ENV vars first - for Render deployment
    env_cfg = {
        "api_key": os.getenv("ANGEL_API_KEY") or os.getenv("angel_api_key"),
        "client_id": os.getenv("ANGEL_CLIENT_ID") or os.getenv("angel_client_id"),
        "password": os.getenv("ANGEL_PASSWORD") or os.getenv("angel_password"),
        "totp_secret": os.getenv("ANGEL_TOTP_SECRET") or os.getenv("angel_totp_secret"),
        "telegram_token": os.getenv("TELEGRAM_BOT_TOKEN") or os.getenv("telegram_bot_token") or "",
        "telegram_chat": os.getenv("TELEGRAM_CHAT_ID") or os.getenv("telegram_chat_id") or "",
        "max_loss": float(os.getenv("MAX_DAILY_LOSS", "1500")),
        "max_trades": int(os.getenv("MAX_TRADES", "5")),
        "lot_size": int(os.getenv("LOT_SIZE", "1")),
        "nifty_qty": int(os.getenv("NIFTY_QTY", "65"))
    }
    # If ENV has api_key, use ENV (Render)
    if env_cfg["api_key"] and env_cfg["client_id"]:
        print("[CONFIG] Using ENV vars (Render deployment)")
        return env_cfg
    
    # Else load from config.json (Local/VPS)
    try:
        with open(CONFIG_FILE,"r",encoding="utf-8") as f:
            cfg=json.load(f)
        print(f"[CONFIG] Using {CONFIG_FILE} (Local)")
        return {
            "api_key": get_key(cfg,"angel_api_key","api_key"),
            "client_id": get_key(cfg,"angel_client_id","client_id"),
            "password": get_key(cfg,"angel_password","password"),
            "totp_secret": get_key(cfg,"angel_totp_secret","totp_secret"),
            "telegram_token": get_key(cfg,"telegram_bot_token","telegram_token") or "",
            "telegram_chat": str(get_key(cfg,"telegram_chat_id","chat_id",default="") or ""),
            "max_loss": float(get_key(cfg,"max_daily_loss",default=1500) or 1500),
            "max_trades": int(get_key(cfg,"max_trades",default=5) or 5),
            "lot_size": int(get_key(cfg,"lot_size",default=1) or 1),
            "nifty_qty": int(get_key(cfg,"nifty_qty",default=65) or 65)
        }
    except Exception as e:
        print(f"[CONFIG] Error: {e} - Trying ENV fallback")
        return env_cfg

def get_key(cfg, *names, default=None):
    lower={str(k).lower():v for k,v in cfg.items()}
    for n in names:
        if n in cfg: return cfg[n]
        if n.lower() in lower: return lower[n.lower()]
    return default


def init_files():
    if not os.path.exists(PAPER_FILE):
        with open(PAPER_FILE,"w",newline="",encoding="utf-8") as f:
            csv.writer(f).writerow(["timestamp","signal_id","direction","spot","trend_high","trend_low","fib_032","fib_050","fib_214","w_pattern","status","reason","strike","otype","entry_ltp","exit_ltp","pnl","balance","candle_time","expiry","trail_sl","token_status"])
    if not os.path.exists(TRADES_FILE):
        with open(TRADES_FILE,"w",newline="",encoding="utf-8") as f:
            csv.writer(f).writerow(["Time","Symbol","Type","Strike","Entry","Exit","Qty","PnL","Reason","Balance","Spot","TrendHi/Lo","W_Pattern","SignalID","CandleTime","TrailSL"])

def read_pnl():
    try:
        with open(PNL_FILE,"r") as f: return float(f.read().strip() or 0)
    except: return 0
def write_pnl(v):
    with open(PNL_FILE,"w") as f: f.write(str(v))

# ============ AUTO TOKEN REGENERATE ============
def login_smartapi(cfg):
    """AUTO TOKEN REGENERATE - TOTP auto + JWT + Feed Token"""
    try:
        from SmartApi import SmartConnect
        import pyotp
    except:
        os.system("python -m pip install smartapi-python pyotp requests --quiet")
        os.system("py -m pip install smartapi-python pyotp requests --quiet")
        from SmartApi import SmartConnect
        import pyotp
    smart=SmartConnect(api_key=cfg["api_key"])
    # TOTP auto generates - har 30 sec la nava code
    totp=pyotp.TOTP(cfg["totp_secret"]).now()
    print(f"[LOGIN] TOTP {totp} Client {cfg['client_id']} - Auto Generated (30 sec valid)")
    resp=smart.generateSession(cfg["client_id"], cfg["password"], totp)
    if not resp or not resp.get("status"):
        raise RuntimeError(f"Login fail {resp}")
    jwt = str(resp['data'].get('jwtToken',''))[:25]
    feed = str(resp['data'].get('feedToken',''))[:20]
    print(f"✅ Login OK {resp['data']['clientcode']} | JWT: {jwt}... | Feed: {feed}... | Auto Regenerated!")
    print(f"   Token Valid Till Tonight 11:59 PM - Udya parat auto login hoil")
    print(f"   TOTP: Auto (30 sec), JWT: Auto (1 day), Feed: Auto")
    return smart

last_login_time = None

def ensure_login(smart, cfg):
    """Har 6 tasane auto re-login - Token expire hone adhi"""
    global last_login_time
    now = datetime.now()
    if last_login_time is None:
        last_login_time = now
        return smart
    # 6 hours zale ki nava token
    if (now - last_login_time).total_seconds() > 6*3600:
        print(f"[AUTO-TOKEN] 6 hours zale - Token auto regenerate karatoy... Time: {now.strftime('%H:%M:%S')}")
        try:
            new_smart = login_smartapi(cfg)
            last_login_time = now
            print(f"[AUTO-TOKEN] ✅ Nava Token Generated at {now.strftime('%H:%M:%S')} - Bot continue!")
            return new_smart
        except Exception as e:
            print(f"[AUTO-TOKEN] Failed: {e} - Juna token vapartoy")
            return smart
    return smart

def check_token_expired(resp):
    if not resp:
        return False
    err_str = str(resp).lower()
    keywords = ["token expired", "invalid token", "session expired", "unauthorized", "jwt", "authentication failed", "ag8001", "ag8002", "invalidtoken"]
    return any(k in err_str for k in keywords)

def get_candles_1min(smart, cfg):
    """Candle + Auto Token Regenerate on expiry"""
    try:
        end=datetime.now()
        start=end-timedelta(minutes=90)
        params={"exchange":NIFTY_EXCH,"symboltoken":NIFTY_TOKEN,"interval":"ONE_MINUTE","fromdate":start.strftime("%Y-%m-%d %H:%M"),"todate":end.strftime("%Y-%m-%d %H:%M")}
        resp=smart.getCandleData(params)
        # Token expired check - jar expired asel tar auto login
        if check_token_expired(resp):
            print(f"[TOKEN EXPIRED] Angel says token expired: {resp}")
            print(f"[AUTO-REGENERATE] Nava token generate karatoy...")
            smart = login_smartapi(cfg)
            # Parat try
            resp=smart.getCandleData(params)
            print(f"[AUTO-REGENERATE] ✅ Nava token ne data magavla!")
        if not resp or not resp.get("status") or not resp.get("data"):
            print(f"[INFO] Market Closed / No Data: {resp} - Waiting...")
            return None, smart
        candles=[]
        for r in resp["data"]:
            if len(r)>=6:
                try: ct=datetime.fromisoformat(r[0].replace("Z","+00:00"))
                except:
                    try: ct=datetime.strptime(r[0], "%Y-%m-%dT%H:%M:%S%z")
                    except: ct=datetime.now()
                candles.append({"time":r[0],"time_dt":ct,"open":float(r[1]),"high":float(r[2]),"low":float(r[3]),"close":float(r[4]),"volume":float(r[5])})
        if len(candles)<TREND_LOOKBACK+5:
            print(f"[INFO] Not enough candles {len(candles)} - Market may be closed")
            return None, smart
        last_dt=candles[-1]["time_dt"]
        try: age=(datetime.now(last_dt.tzinfo)-last_dt).total_seconds()/60
        except: age=(datetime.now()-last_dt.replace(tzinfo=None)).total_seconds()/60
        if age>60:
            print(f"[INFO] Market Closed - Last candle {candles[-1]['time']} {age:.0f} min old - Waiting...")
            return None, smart
        return candles, smart
    except Exception as e:
        err=str(e).lower()
        if "token" in err or "session" in err or "unauthorized" in err or "ag800" in err:
            print(f"[TOKEN ERROR] {e} - Auto re-login try karatoy...")
            try:
                new_smart = login_smartapi(cfg)
                global last_login_time
                last_login_time = datetime.now()
                print(f"[AUTO-REGENERATE] ✅ Nava token generate zala!")
                return None, new_smart
            except Exception as e2:
                print(f"[AUTO-REGENERATE] Failed: {e2}")
        print(f"[INFO] Candle error: {e} - Waiting...")
        return None, smart

def detect_w_pattern_trend(candles, lookback=30):
    if len(candles)<lookback: return None
    window=candles[-lookback:]
    lows=[]
    for i in range(1,len(window)-1):
        if window[i]["low"] < window[i-1]["low"] and window[i]["low"] < window[i+1]["low"]:
            lows.append((i, window[i]))
    if len(lows)<2:
        sorted_lows=sorted(window, key=lambda x: x["low"])[:3]
        lows=[(0, sorted_lows[0]), (1, sorted_lows[1])]
    for idx1 in range(len(lows)):
        for idx2 in range(idx1+1, len(lows)):
            i1,c1=lows[idx1]; i2,c2=lows[idx2]
            if abs(i2-i1)<3: continue
            low1=c1["low"]; low2=c2["low"]
            avg_low=(low1+low2)/2
            if abs(low1-low2)/avg_low>0.06: continue
            start=min(i1,i2); end=max(i1,i2)
            between=window[start:end+1] if start<end else window
            if not between: continue
            peak=max(between, key=lambda x: x["high"])
            peak_high=peak["high"]
            if peak_high < avg_low*1.08: continue
            return {"found": True, "low1": round(low1,2), "low2": round(low2,2), "peak": round(peak_high,2), "low1_time": c1["time"], "low2_time": c2["time"], "peak_time": peak["time"], "neckline": round(peak_high,2), "avg_low": round(avg_low,2)}
    return None

def make_signal_trend_fib(candles):
    if len(candles)<TREND_LOOKBACK+2: return None
    recent=candles[-1]; prior=candles[-2]
    trend_window=candles[-TREND_LOOKBACK:]
    trend_high=max(c["high"] for c in trend_window)
    trend_low=min(c["low"] for c in trend_window)
    range_val=trend_high-trend_low
    if range_val<=10: return None
    fib_050=trend_low + range_val*FIB_ENTRY
    fib_032_bull=trend_low + range_val*FIB_SL
    fib_032_bear=trend_high - range_val*FIB_SL
    fib_214_bull=trend_low + range_val*FIB_TARGET
    fib_214_bear=trend_high - range_val*FIB_TARGET
    bullish_cross = prior["close"] <= fib_050 and recent["close"] > fib_050
    bearish_cross = prior["close"] >= fib_050 and recent["close"] < fib_050
    w_pattern=detect_w_pattern_trend(candles, lookback=TREND_LOOKBACK)
    if bullish_cross or bearish_cross:
        if bullish_cross:
            direction="CALL_BIAS"; otype="CE"; fib_032=fib_032_bull; fib_214=fib_214_bull; cross_type="UP"
        else:
            direction="PUT_BIAS"; otype="PE"; fib_032=fib_032_bear; fib_214=fib_214_bear; cross_type="DOWN"
        return {
            "id": datetime.now().strftime("%Y%m%d%H%M%S"),
            "direction": direction, "otype": otype,
            "spot": round(recent["close"],2),
            "trend_high": round(trend_high,2), "trend_low": round(trend_low,2), "range": round(range_val,2),
            "fib_032": round(fib_032,2), "fib_050": round(fib_050,2), "fib_214": round(fib_214,2),
            "reason": f"TREND Hi {trend_high:.2f} Lo {trend_low:.2f} Range {range_val:.2f} | Fib 0.5 Cross {cross_type} | {'W FOUND' if w_pattern and w_pattern['found'] else 'No W'}",
            "candle_time": recent["time"], "candle_time_dt": recent["time_dt"],
            "prior_close": prior["close"], "recent_close": recent["close"],
            "w_pattern": w_pattern, "cross_type": cross_type
        }
    return None

def get_real_option_ltp(smart, spot, otype):
    try:
        step=50; atm=round(spot/step)*step
        strike = atm+50 if otype=="CE" else atm-50
        search_q=f"NIFTY {strike} {otype}"
        try:
            res=smart.searchScrip("NFO", search_q)
            if res and res.get("data"):
                first=res["data"][0]
                token=first.get("symboltoken") or first.get("token")
                tradingsymbol=first.get("tradingsymbol") or first.get("symbol")
                if token:
                    ltp_resp=smart.ltpData("NFO", tradingsymbol, token)
                    if ltp_resp and ltp_resp.get("data") and ltp_resp["data"].get("ltp"):
                        ltp=float(ltp_resp["data"]["ltp"])
                        return strike, ltp, tradingsymbol, token
        except: pass
        import random
        base=max(20, 100 - abs(spot-strike)*0.5)
        return strike, round(base + random.uniform(-3,3),2), f"NIFTY {strike}{otype} EST", None
    except:
        return round(spot/50)*50, 50.0, "EST", None

def telegram_send(cfg, text, markup=None):
    if not cfg["telegram_token"] or not cfg["telegram_chat"]:
        print(text)
        return None
    url=f"https://api.telegram.org/bot{cfg['telegram_token']}/sendMessage"
    payload={"chat_id": cfg["telegram_chat"], "text": text}
    if markup: payload["reply_markup"]=markup
    try:
        r=requests.post(url, json=payload, timeout=10)
        r.raise_for_status()
        j=r.json()
        return j if j.get("ok") else None
    except Exception as e:
        print(f"Telegram error {e}")
        return None

def poll_telegram(cfg, offset):
    if not cfg["telegram_token"]: return offset, []
    url=f"https://api.telegram.org/bot{cfg['telegram_token']}/getUpdates"
    try:
        r=requests.get(url, params={"timeout":1, "offset":offset}, timeout=6)
        r.raise_for_status()
        j=r.json()
        events=[]
        for upd in j.get("result",[]):
            offset=max(offset, int(upd["update_id"])+1)
            cb=upd.get("callback_query")
            if not cb: continue
            chat_id=str(cb.get("message",{}).get("chat",{}).get("id",""))
            if cfg["telegram_chat"] and chat_id!=cfg["telegram_chat"]: continue
            events.append({"data":cb.get("data",""), "callback_id":cb.get("id")})
        return offset, events
    except: return offset, []

def answer_callback(cfg, cid, txt):
    if not cfg["telegram_token"]: return
    url=f"https://api.telegram.org/bot{cfg['telegram_token']}/answerCallbackQuery"
    try: requests.post(url, json={"callback_query_id":cid, "text":txt}, timeout=5)
    except: pass

def log_paper(signal, status, strike, otype, entry, exit_ltp, pnl, bal, expiry, trail):
    with open(PAPER_FILE,"a",newline="",encoding="utf-8") as f:
        w=signal.get("w_pattern")
        csv.writer(f).writerow([
            datetime.now().isoformat(timespec="seconds"), signal["id"], signal["direction"],
            signal["spot"], signal["trend_high"], signal["trend_low"],
            signal["fib_032"], signal["fib_050"], signal["fib_214"],
            "YES" if w and w.get("found") else "NO",
            status, signal["reason"], strike, otype, entry, exit_ltp, pnl, bal,
            signal.get("candle_time",""), expiry, trail, "AUTO_TOKEN"
        ])

def log_trade(signal, strike, otype, entry, exit_ltp, qty, pnl, reason, bal, trail):
    now=datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    w=signal.get("w_pattern")
    with open(TRADES_FILE,"a",newline="",encoding="utf-8") as f:
        csv.writer(f).writerow([now,"NIFTY",otype,strike,entry,exit_ltp,qty,pnl,reason,bal,signal["spot"],f"{signal['trend_high']}/{signal['trend_low']}",f"W:{w['low1']}/{w['low2']}/{w['peak']}" if w and w.get("found") else "No W",signal["id"],signal.get("candle_time",""),trail])

def main():
    global last_login_time
    print(f"=== NIFTY BOT - TREND HIGH-LOW FIB + W PATTERN + AUTO TOKEN REGENERATE ===")
    print(f"Trend Lookback {TREND_LOOKBACK} | Auto Token: TOTP 30sec + JWT 1day + Auto Re-login 6hr")
    cfg=load_config()
    init_files()
    pnl_today=read_pnl()
    smart=login_smartapi(cfg)
    last_login_time = datetime.now()
    telegram_send(cfg, f"🚀 <b>NIFTY TREND FIB BOT + AUTO TOKEN STARTED</b>\nClient: {cfg['client_id']}\nTime: {datetime.now().strftime('%H:%M:%S')}\nLogic: TREND High-Low (Last {TREND_LOOKBACK}) | Fib 0.5/0.32/2.14 + W Pattern\n🔑 Token: Auto Regenerate ON - TOTP 30sec + JWT 6hr + Expiry Auto Login\nMode: REAL LTP Paper Only")
    offset=0; seen=set(); trades_today=0
    try:
        with open(TRADES_FILE,"r") as f: trades_today=max(0,len(list(csv.reader(f)))-1)
    except: trades_today=0
    pending_signal=None; pending_info=None; pending_created=None
    while True:
        now=datetime.now()
        if now.hour>15 or (now.hour==15 and now.minute>=15):
            print("15:15 close"); telegram_send(cfg, f"⏰ Close PnL Rs.{pnl_today:.2f} Token Auto Expire Tonight"); break
        try:
            smart = ensure_login(smart, cfg)
            offset, events = poll_telegram(cfg, offset)
            for ev in events:
                data=ev["data"]; cb_id=ev["callback_id"]
                if pending_signal and pending_created:
                    age=(now-pending_created).total_seconds()/60
                    if age>SIGNAL_EXPIRY:
                        telegram_send(cfg, f"⏰ EXPIRED {pending_signal['id']}")
                        log_paper(pending_signal, f"EXPIRED", pending_info["strike"], pending_info["otype"], pending_info["entry"], "", 0, pnl_today, "", "")
                        answer_callback(cfg, cb_id, "Expired!")
                        pending_signal=None; pending_info=None; pending_created=None
                        continue
                if data.startswith("YES_"):
                    sig_id=data.split("_",1)[1]
                    if pending_signal and pending_signal["id"]==sig_id:
                        answer_callback(cfg, cb_id, "Approved!")
                        log_paper(pending_signal, "PAPER_APPROVED", pending_info["strike"], pending_info["otype"], pending_info["entry"], "", 0, pnl_today, "", pending_signal["fib_032"])
                        with open("open_position.json","w") as f:
                            json.dump({"signal":pending_signal, "info":pending_info, "entry":pending_info["entry"], "time":now.isoformat(), "created":pending_created.isoformat() if pending_created else now.isoformat(), "trail_sl":pending_signal["fib_032"], "highest":pending_info["entry"]}, f)
                        w=pending_signal.get("w_pattern")
                        w_txt=f"W YES Low1 {w['low1']} Low2 {w['low2']}" if w and w.get("found") else "W NO"
                        telegram_send(cfg, f"✅ PAPER APPROVED - TREND FIB + AUTO TOKEN\nSignal: {sig_id}\nTREND Hi {pending_signal['trend_high']} Lo {pending_signal['trend_low']}\n{w_txt}\nStrike {pending_info['strike']} {pending_info['otype']} Entry Rs.{pending_info['entry']}\nTrailing SL ON | Token Auto")
                        pending_signal=None; pending_info=None; pending_created=None
                    else:
                        answer_callback(cfg, cb_id, "No pending")
                elif data.startswith("NO_"):
                    sig_id=data.split("_",1)[1]
                    answer_callback(cfg, cb_id, "Skipped")
                    if pending_signal and pending_signal["id"]==sig_id:
                        log_paper(pending_signal, "SKIPPED", pending_info["strike"], pending_info["otype"], pending_info["entry"], "", 0, pnl_today, "", "")
                        telegram_send(cfg, f"❌ SKIPPED {sig_id}")
                        pending_signal=None; pending_info=None; pending_created=None
            if pending_signal and pending_created:
                age=(now-pending_created).total_seconds()/60
                if age>SIGNAL_EXPIRY:
                    telegram_send(cfg, f"⏰ AUTO EXPIRED {pending_signal['id']}")
                    log_paper(pending_signal, "AUTO_EXPIRED", pending_info["strike"], pending_info["otype"], pending_info["entry"], "", 0, pnl_today, "", "")
                    pending_signal=None; pending_info=None; pending_created=None
            open_path="open_position.json"
            if os.path.exists(open_path):
                try:
                    with open(open_path,"r") as f: open_data=json.load(f)
                    info=open_data["info"]; signal=open_data["signal"]; entry=open_data["entry"]
                    token=info.get("token"); tradingsymbol=info.get("tradingsymbol")
                    strike=info["strike"]; otype=info["otype"]
                    trail_sl=open_data.get("trail_sl", signal["fib_032"])
                    highest=open_data.get("highest", entry)
                    cur_ltp=None
                    if token and tradingsymbol and "EST" not in tradingsymbol:
                        try:
                            ltp_resp=smart.ltpData("NFO", tradingsymbol, token)
                            if ltp_resp and ltp_resp.get("data"): cur_ltp=float(ltp_resp["data"]["ltp"])
                        except Exception as e:
                            if check_token_expired(e):
                                print(f"[TOKEN EXPIRED in LTP] Auto re-login...")
                                smart = login_smartapi(cfg)
                                last_login_time = datetime.now()
                    if cur_ltp is None:
                        try:
                            ltp_data=smart.ltpData("NSE","NIFTY",NIFTY_TOKEN)
                            cur_spot=float(ltp_data["data"]["ltp"])
                            diff=cur_spot - signal["spot"]
                            cur_ltp = entry + diff*0.6 if otype=="CE" else entry - diff*0.6
                            cur_ltp=max(5, cur_ltp)
                        except: cur_ltp=entry
                    pnl_now=(cur_ltp-entry)*65*1
                    if cur_ltp>highest:
                        highest=cur_ltp
                        if highest>entry*1.2: trail_sl=max(trail_sl, entry)
                        if highest>entry*1.4: trail_sl=max(trail_sl, entry + (highest-entry)*0.5)
                        open_data["trail_sl"]=trail_sl; open_data["highest"]=highest
                        with open(open_path,"w") as f: json.dump(open_data,f)
                    hit=False; reason=""
                    if cur_ltp>=entry*1.6:
                        hit=True; reason=f"Fib 2.14 Target Hit"
                    elif cur_ltp<=trail_sl:
                        hit=True; reason=f"Trailing SL Hit"
                    open_time=datetime.fromisoformat(open_data["time"])
                    if (now-open_time).total_seconds()>1800: hit=True; reason=f"Time Exit 30min"
                    if now.hour==15 and now.minute>=10: hit=True; reason=f"Auto Square-off 15:10"
                    if hit:
                        pnl_today+=pnl_now; trades_today+=1; write_pnl(pnl_today)
                        log_trade(signal, strike, otype, entry, round(cur_ltp,2), 65, round(pnl_now,2), reason, round(pnl_today,2), round(trail_sl,2))
                        log_paper(signal, f"CLOSED", strike, otype, entry, round(cur_ltp,2), round(pnl_now,2), round(pnl_today,2), "", round(trail_sl,2))
                        emoji="🟢" if pnl_now>0 else "🔴"
                        telegram_send(cfg, f"{emoji} PAPER CLOSED PnL Rs.{pnl_now:.2f} Total Rs.{pnl_today:.2f} Token Auto OK")
                        os.remove(open_path)
                        if pnl_today<=-cfg["max_loss"]: break
                        if trades_today>=cfg["max_trades"]: break
                    else:
                        print(f"[{now.strftime('%H:%M:%S')}] Open {otype} {strike} Entry {entry} LTP {cur_ltp:.2f} Trail {trail_sl:.2f} Token Auto OK")
                except Exception as e:
                    print(f"Tracking error {e}")
            if now.hour<9 or (now.hour==9 and now.minute<15):
                print(f"[{now.strftime('%H:%M:%S')}] Outside 9:15-15:15 - Token Auto Valid"); time.sleep(POLL_SECONDS); continue
            if pending_signal or os.path.exists(open_path):
                time.sleep(POLL_SECONDS); continue
            try:
                candles, smart = get_candles_1min(smart, cfg)
                if candles is None:
                    print(f"[{now.strftime('%H:%M:%S')}] Market Closed - Waiting 60 sec... Token Auto Valid")
                    time.sleep(60)
                    continue
                signal=make_signal_trend_fib(candles)
                if not signal:
                    print(f"[{now.strftime('%H:%M:%S')}] No signal. Trend Hi {max(c['high'] for c in candles[-30:]):.2f} Lo {min(c['low'] for c in candles[-30:]):.2f} Token Auto OK")
                    time.sleep(POLL_SECONDS); continue
                if signal["id"] in seen:
                    time.sleep(POLL_SECONDS); continue
                seen.add(signal["id"])
                strike, ltp, tradingsymbol, token = get_real_option_ltp(smart, signal["spot"], signal["otype"])
                print(f"🔔 SIGNAL TREND FIB + AUTO TOKEN: {signal['direction']} Spot {signal['spot']} TREND Hi {signal['trend_high']} Lo {signal['trend_low']} Strike {strike} LTP {ltp}")
                expiry_dt=datetime.now()+timedelta(minutes=SIGNAL_EXPIRY)
                log_paper(signal, "AWAITING_CONFIRMATION", strike, signal["otype"], ltp, "", 0, pnl_today, expiry_dt.isoformat(), signal["fib_032"])
                w=signal.get("w_pattern")
                text=(
                    f"🚨 <b>TREND FIB + AUTO TOKEN SIGNAL #{signal['id']}</b>\n"
                    f"Bias: {signal['direction']} ({signal['otype']}) - {'STRONG W' if w and w.get('found') else 'Trend Fib'}\n"
                    f"📅 Candle: {signal['candle_time']} (1Min)\n"
                    f"TREND Hi: {signal['trend_high']} Lo: {signal['trend_low']} Range: {signal['range']}\n"
                    f"Fib 0.5: {signal['fib_050']} | 0.32 SL: {signal['fib_032']} | 2.14: {signal['fib_214']}\n"
                    f"{'🔥 W PATTERN FOUND!' if w and w.get('found') else 'No W'}\n"
                    f"Strike: {strike} {signal['otype']} Entry LTP: Rs.{ltp}\n"
                    f"🔑 Token: Auto Regenerate ON - TOTP 30sec + JWT Auto\n"
                    f"Target: Rs.{ltp*1.6:.2f} | SL: Rs.{signal['fib_032']} Trail ON"
                )
                keyboard={"inline_keyboard": [[{"text": "✅ YES", "callback_data": f"YES_{signal['id']}"}, {"text": "❌ NO", "callback_data": f"NO_{signal['id']}"}]]}
                res=telegram_send(cfg, text, keyboard)
                if res:
                    pending_signal=signal; pending_info={"strike":strike, "otype":signal["otype"], "entry":ltp, "tradingsymbol":tradingsymbol, "token":token}; pending_created=datetime.now()
            except Exception as e:
                print(f"[{now.strftime('%H:%M:%S')}] Error: {e}")
            time.sleep(POLL_SECONDS)
        except KeyboardInterrupt:
            print("Stopped"); break
        except Exception as e:
            print(f"Loop error {e}"); time.sleep(10)

if __name__=="__main__":
    main()
